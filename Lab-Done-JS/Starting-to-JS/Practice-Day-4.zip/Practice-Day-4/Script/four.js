let fullname = prompt("Nhập họ tên: ");
let age = prompt("Nhập tuổi: ");
let address = prompt("Nhập địa chỉ: ");
let phone = prompt("Nhập số điện thoại: ");
let sex = prompt("Nhập giới tính: ");

document.getElementById("fullname").innerHTML = fullname;
document.getElementById("age").innerHTML = age;
document.getElementById("address").innerHTML = address;
document.getElementById("phone").innerHTML = phone;
document.getElementById("sex").innerHTML = sex;