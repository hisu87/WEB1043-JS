let a = 2
let b = 1

var c = (a - b) * 0
var c1 = (a + b) * 0
var c2 = a + b * -2
var c3 = a * -1 + b * 2
var c4 = a * -1 - b * -2
var c5 = b - a + 1
var c6 = a % b
var c7 = a % b * 0
var c8 = a / b * 0
var c9 = b / a * 0

// Print to screen
console.log(c)
console.log(c1);
console.log(c2);
console.log(c3);
console.log(c4);
console.log(c5);
console.log(c6);
console.log(c7);
console.log(c8);

