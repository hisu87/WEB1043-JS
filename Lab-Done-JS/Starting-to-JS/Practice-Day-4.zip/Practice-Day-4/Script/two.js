var a = 5;
document.write(a)
a++
document.write(a);
var b = a --
document.write(b)
var c = --a
document.write(c)
c +=10
c -=a
document.write(c);
var d = 2
c /= d
document.write(c);
